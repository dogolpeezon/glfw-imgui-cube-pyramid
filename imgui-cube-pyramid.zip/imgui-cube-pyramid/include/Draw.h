//
// Draw.h
// Created by Douglas Pearson 28/09/17.
//
#ifndef DRAW
#define DRAW

#include <iostream>
#include "AnimManage.h"
using namespace std;

class Draw{
public:
    Draw();
    ~Draw();

    void Pyramid();
    void Cube();
    void Gui();

private:
};

#endif
